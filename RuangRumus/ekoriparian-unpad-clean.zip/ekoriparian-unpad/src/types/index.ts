export interface WaterQualityData {
  timestamp: string;
  ph: number;
  tds: number; // ppm
  do: number; // mg/L Dissolved Oxygen
  turbidity: number; // NTU
  temperature: number; // °C
  status: 'Sangat Baik' | 'Baik' | 'Sedang' | 'Perhatian';
}

export interface WaterQualityRecord {
  id: string | number;
  timestamp: string;
  station: string;
  ph: number;
  do: number;
  temp: number;
  turbidity: number;
  tds: number;
  weather: string;
  flow: string;
  recorder: string;
  notes: string;
  photoUrl?: string;
}

export interface EcoMetric {
  title: string;
  value: string;
  unit: string;
  change: string;
  status: 'positive' | 'neutral' | 'warning';
  description: string;
}

export interface HistoryEvent {
  year: string;
  title: string;
  description: string;
  category: 'Pra-Pembangunan' | 'Peresmian' | 'Pengembangan' | 'Program';
}

export interface FunctionModule {
  id: string;
  title: string;
  iconName: string;
  shortDesc: string;
  detailedDesc: string;
  highlights: string[];
  image: string;
  color: string;
}

export interface PlantFlora {
  name: string;
  latinName: string;
  category: string;
  role: string;
  count?: string;
}

export interface FishFauna {
  name: string;
  latinName: string;
  status: 'Asli Citarum' | 'Dipertahankan' | 'Restorasi';
  description: string;
}
