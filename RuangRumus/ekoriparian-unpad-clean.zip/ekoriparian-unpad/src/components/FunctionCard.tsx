import React from 'react';
import { FunctionModule } from '../types';
import { Droplets, GraduationCap, Trees, Fish, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

const iconMap: Record<string, React.ReactNode> = {
  Droplets: <Droplets className="w-5 h-5 text-emerald-700" />,
  GraduationCap: <GraduationCap className="w-5 h-5 text-blue-700" />,
  Trees: <Trees className="w-5 h-5 text-teal-700" />,
  Fish: <Fish className="w-5 h-5 text-cyan-700" />,
};

interface FunctionCardProps {
  item: FunctionModule;
  index: number;
}

export const FunctionCard: React.FC<FunctionCardProps> = ({ item, index }) => {
  return (
    <div className="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col group justify-between">
      <div>
        <div className="relative h-48 sm:h-52 overflow-hidden bg-slate-100">
          <img
            src={item.image}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
          <div className="absolute top-3 left-3 bg-white p-2 rounded-xl shadow-sm border border-slate-200">
            {iconMap[item.iconName]}
          </div>
          <div className="absolute bottom-3 left-3 right-3 text-white">
            <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded bg-emerald-800 text-white inline-block mb-1">
              Fungsi #{index + 1}
            </span>
            <h3 className="text-base font-bold leading-snug text-white">{item.title}</h3>
          </div>
        </div>

        <div className="p-5 space-y-3">
          <p className="text-slate-600 text-xs leading-relaxed">
            {item.shortDesc}
          </p>

          <div className="space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <p className="text-[11px] font-bold text-slate-800 mb-1">Cakupan Keunggulan:</p>
            {item.highlights.slice(0, 3).map((hl, i) => (
              <div key={i} className="flex items-start gap-1.5 text-xs text-slate-700">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700 shrink-0 mt-0.5" />
                <span>{hl}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-5 pt-0">
        <Link
          to={`/fungsi#${item.id}`}
          className="inline-flex items-center justify-center gap-1.5 w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-emerald-900 text-white font-semibold text-xs transition-colors"
        >
          <span>Pelajari Selengkapnya</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
};
