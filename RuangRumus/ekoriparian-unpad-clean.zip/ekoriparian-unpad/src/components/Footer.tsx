import React from 'react';
import { Link } from 'react-router-dom';
import { Droplets, MapPin, ExternalLink, ShieldCheck, Globe, Layers, BookOpen } from 'lucide-react';
import { EKORIPARIAN_INFO } from '../data/ekoparianData';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-950 text-emerald-100 border-t border-emerald-900 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Brand & Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold shadow-sm">
                <Droplets className="w-6 h-6" />
              </div>
              <span className="font-extrabold text-xl text-white">
                Leuwi Padjadjaran
              </span>
            </div>
            <p className="text-xs text-emerald-200/80 leading-relaxed">
              Fasilitas ekoriparian berbasis danau/setu di kawasan kampus Universitas Padjadjaran Jatinangor untuk restorasi air danau, konservasi lingkungan, dan sarana riset terbuka civitas akademika.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-300 bg-emerald-900/60 p-2.5 rounded-lg border border-emerald-800">
              <MapPin className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>Jatinangor, Kabupaten Sumedang, Jawa Barat</span>
            </div>
          </div>

          {/* Navigasi Utama */}
          <div>
            <h3 className="text-white font-bold text-sm mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" /> Navigasi Informasi
            </h3>
            <ul className="space-y-2 text-xs text-emerald-200/90">
              <li>
                <Link to="/" className="hover:text-white transition-colors flex items-center gap-1.5">
                  › Beranda Ekoriparian
                </Link>
              </li>
              <li>
                <Link to="/sejarah" className="hover:text-white transition-colors flex items-center gap-1.5">
                  › Sejarah & Latar Belakang
                </Link>
              </li>
              <li>
                <Link to="/fungsi" className="hover:text-white transition-colors flex items-center gap-1.5">
                  › 4 Fungsi Utama Ekoriparian
                </Link>
              </li>
              <li>
                <Link to="/kualitas-air" className="hover:text-white transition-colors flex items-center gap-1.5">
                  › Data Kualitas Air Mandiri
                </Link>
              </li>
              <li>
                <Link to="/keanekaragaman-hayati" className="hover:text-white transition-colors flex items-center gap-1.5">
                  › Flora & Fauna Endemik
                </Link>
              </li>
              <li>
                <Link to="/panduan" className="hover:text-white transition-colors flex items-center gap-1.5">
                  › Panduan Kunjungan Lapangan
                </Link>
              </li>
            </ul>
          </div>

          {/* Fakta Konservasi */}
          <div>
            <h3 className="text-white font-bold text-sm mb-4 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Informasi Kawasan
            </h3>
            <ul className="space-y-2.5 text-xs text-emerald-200/80">
              <li className="bg-emerald-900/40 p-2.5 rounded-lg border border-emerald-800/60">
                <strong className="text-emerald-100 block">Diresmikan:</strong>
                {EKORIPARIAN_INFO.inaugurationDate} di Kampus Unpad
              </li>
              <li className="bg-emerald-900/40 p-2.5 rounded-lg border border-emerald-800/60">
                <strong className="text-emerald-100 block">Luas Area Restorasi:</strong>
                {EKORIPARIAN_INFO.areaSize}
              </li>
              <li className="bg-emerald-900/40 p-2.5 rounded-lg border border-emerald-800/60">
                <strong className="text-emerald-100 block">Status Parameter Air:</strong>
                pH 7.5 (Kategori Normal dan Memenuhi Baku Mutu)
              </li>
            </ul>
          </div>

          {/* Tautan Kampus & Kontak */}
          <div>
            <h3 className="text-white font-bold text-sm mb-4 flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-400" /> Tautan Terkait
            </h3>
            <div className="space-y-2.5 text-xs">
              <a
                href="https://www.unpad.ac.id"
                target="_blank"
                rel="noreferrer"
                className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-900/40 hover:bg-emerald-900/80 text-emerald-200 hover:text-white transition-all border border-emerald-800/60"
              >
                <span>Portal Resmi Universitas Padjadjaran</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <Link
                to="/panduan"
                className="flex items-center justify-between p-2.5 rounded-lg bg-emerald-900/40 hover:bg-emerald-900/80 text-emerald-200 hover:text-white transition-all border border-emerald-800/60"
              >
                <span>Panduan Etika & Observasi</span>
                <BookOpen className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-8 border-t border-emerald-900/80 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-emerald-300/70">
          <p>© 2026 Ekoriparian Leuwi Padjadjaran — Universitas Padjadjaran. Seluruh Hak Cipta Dilindungi.</p>
          <p>
            Portal Informasi Lingkungan & Kualitas Air Danau Kampus Jatinangor.
          </p>
        </div>
      </div>
    </footer>
  );
};
