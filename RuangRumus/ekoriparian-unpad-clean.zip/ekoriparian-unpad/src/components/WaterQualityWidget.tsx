import React, { useState, useEffect } from 'react';
import { 
  Droplets, 
  FlaskConical, 
  Wind, 
  Thermometer, 
  Layers, 
  PlusCircle, 
  Clock, 
  MapPin, 
  Eye, 
  CheckCircle2, 
  AlertCircle, 
  X, 
  Camera, 
  RotateCcw,
  ChevronDown
} from 'lucide-react';
import { DEFAULT_WATER_RECORDS } from '../data/ekoparianData';
import { WaterQualityRecord } from '../types';

const STORAGE_KEY = 'ekoriparian_unpad_water_records_v2';

interface WaterQualityWidgetProps {
  showFullTable?: boolean;
  onRecordCountChange?: (count: number) => void;
}

export const WaterQualityWidget: React.FC<WaterQualityWidgetProps> = ({ 
  showFullTable = false,
}) => {
  const [records, setRecords] = useState<WaterQualityRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_WATER_RECORDS;
  });

  const [selectedStation, setSelectedStation] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form State for Adding New Observation Record
  const [formData, setFormData] = useState({
    station: 'Stasiun 1 - Hulu (Area Konservasi Unpad)',
    ph: 7.5,
    do: 6.8,
    temp: 27,
    turbidity: 9.5,
    tds: 142,
    weather: 'Cerah Berawan',
    flow: 'Tenang / Normal',
    recorder: 'Tim Pengamatan Mandiri Unpad',
    notes: 'Pengamatan in-situ mandiri di lapangan perairan Ekoriparian Leuwi Padjadjaran.'
  });

  // Save to localStorage when records change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
    } catch (e) {
      console.warn('Gagal menyimpan ke localStorage', e);
    }
  }, [records]);

  // Filter records based on selected station
  const filteredRecords = selectedStation === 'all' 
    ? records 
    : records.filter(r => r.station === selectedStation);

  // Active record to display in the main card (latest from filtered)
  const current = filteredRecords[0] || records[0] || DEFAULT_WATER_RECORDS[0];

  const handleOpenModal = () => {
    setFormData(prev => ({
      ...prev,
      station: selectedStation === 'all' ? 'Stasiun 1 - Hulu (Area Konservasi Unpad)' : selectedStation
    }));
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date();
    const timeStr = now.toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' }) + 
      ', ' + now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';

    const newRecord: WaterQualityRecord = {
      id: Date.now(),
      timestamp: timeStr,
      station: formData.station,
      ph: Number(formData.ph),
      do: Number(formData.do),
      temp: Number(formData.temp),
      turbidity: Number(formData.turbidity),
      tds: Number(formData.tds),
      weather: formData.weather,
      flow: formData.flow,
      recorder: formData.recorder.trim() || 'Tim Pengamatan Mandiri Unpad',
      notes: formData.notes.trim() || 'Pengamatan lapangan mandiri.',
      photoUrl: '/images/measurement-ph.jpg'
    };

    setRecords([newRecord, ...records]);
    setIsModalOpen(false);
    setToastMessage('Data pengamatan berhasil ditambahkan!');
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleResetData = () => {
    if (window.confirm('Kembalikan data pengamatan ke data awal lapangan?')) {
      setRecords(DEFAULT_WATER_RECORDS);
      localStorage.removeItem(STORAGE_KEY);
      setToastMessage('Data berhasil direset ke data pengamatan awal.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  // Calculate simple water quality index indicator
  const getPhStatus = (ph: number) => {
    if (ph >= 6.5 && ph <= 8.5) return { label: 'Normal / Netral', color: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    if (ph >= 6.0 && ph <= 9.0) return { label: 'Batas Toleransi', color: 'bg-amber-100 text-amber-800 border-amber-300' };
    return { label: 'Perlu Perhatian', color: 'bg-rose-100 text-rose-800 border-rose-300' };
  };

  const phStatus = getPhStatus(current.ph);

  return (
    <div className="space-y-6">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-900 text-white px-5 py-3 rounded-xl shadow-2xl border border-emerald-700 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
          <span className="text-sm font-semibold">{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="ml-2 text-emerald-300 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Banner Informasi Lokasi & Filter Titik Pantau */}
      <div className="bg-emerald-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg border border-emerald-800/80 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-emerald-800/80 border border-emerald-700 px-3 py-1 rounded-full text-xs font-semibold text-emerald-200">
            <MapPin className="w-3.5 h-3.5 text-emerald-300" />
            <span>Kawasan Ekoriparian Leuwi Padjadjaran, Unpad Jatinangor</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
            Informasi Kualitas Air Danau
          </h2>
          <p className="text-xs sm:text-sm text-emerald-100/90 leading-relaxed">
            Data parameter fisika dan kimia perairan yang dihimpun dari <strong>hasil pengamatan mandiri langsung di lapangan</strong> menggunakan instrumen portabel (digital pH meter dan TDS-3 tester).
          </p>
        </div>

        {/* Filter Stasiun & Tombol Update Data */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto shrink-0">
          <div className="relative">
            <select
              value={selectedStation}
              onChange={(e) => setSelectedStation(e.target.value)}
              className="w-full sm:w-72 bg-emerald-950/90 text-emerald-100 border border-emerald-700/80 rounded-xl px-4 py-2.5 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-400 appearance-none pr-9 cursor-pointer"
            >
              <option value="all">Semua Titik Pantau (3 Stasiun)</option>
              <option value="Stasiun 1 - Hulu (Area Konservasi Unpad)">Stasiun 1 - Hulu (Konservasi)</option>
              <option value="Stasiun 2 - Tengah (Zona Edukasi & Fitoremediasi)">Stasiun 2 - Tengah (Fitoremediasi)</option>
              <option value="Stasiun 3 - Hilir (Outlet Danau & Sempadan Jembatan)">Stasiun 3 - Hilir (Outlet Danau)</option>
            </select>
            <ChevronDown className="w-4 h-4 text-emerald-300 absolute right-3 top-3 pointer-events-none" />
          </div>

          <button
            onClick={handleOpenModal}
            className="inline-flex items-center justify-center gap-2 bg-white hover:bg-emerald-50 active:bg-emerald-100 text-emerald-950 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md transition-colors cursor-pointer shrink-0"
          >
            <PlusCircle className="w-4 h-4 text-emerald-700" />
            <span>Tambah Data Pengamatan</span>
          </button>
        </div>
      </div>

      {/* Ringkasan Status Utama & 4 Parameter Kunci */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Kartu Status Mutu Air & Indeks (Col 4) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-4">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Status Mutu Perairan</span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                BAIK (Kondisi Stabil)
              </span>
            </div>

            <div className="my-4 flex items-baseline gap-3">
              <span className="text-5xl font-black text-slate-900 tracking-tight">84.5</span>
              <span className="text-sm font-semibold text-slate-500">/ 100 (Indeks Mutu)</span>
            </div>

            <p className="text-sm text-slate-600 leading-relaxed mb-4">
              Kondisi perairan danau Leuwi Padjadjaran dalam kondisi bersih dan stabil. Keseimbangan parameter fisik dan kimia mendukung keberlangsungan ikan air tawar serta vegetasi sempadan danau.
            </p>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1 mb-4">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700">Titik Pantau Aktif:</span>
                <span className="text-emerald-700 font-bold truncate max-w-[180px]">{current.station}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-700">Metode Observasi:</span>
                <span className="text-slate-700 font-medium">In-Situ Mandiri</span>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Pencatat Lapangan:</span>
            <span className="font-bold text-slate-800">{current.recorder}</span>
          </div>
        </div>

        {/* Grid 4 Parameter Utama (Col 8) */}
        <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Parameter 1: Derajat Keasaman (pH) */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-emerald-300 transition-colors flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-blue-50 text-blue-700 rounded-xl">
                    <FlaskConical className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">Derajat Keasaman (pH)</h3>
                    <p className="text-xs text-slate-500">Baku Mutu Ideal: 6.0 – 9.0</p>
                  </div>
                </div>
                <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${phStatus.color}`}>
                  {phStatus.label}
                </span>
              </div>

              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-4xl font-extrabold text-slate-900 font-mono">{current.ph}</span>
                <span className="text-sm font-semibold text-slate-500">pH</span>
              </div>

              <p className="text-xs text-slate-600 mt-2">
                Tercatat pada kisaran normal, aman untuk perkembangan biota akuatik tanpa indikasi pengasaman.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500">Uji In-Situ: pH Meter Digital</span>
              <button
                onClick={() => setShowPhotoModal('/images/measurement-ph.jpg')}
                className="text-emerald-700 font-semibold hover:underline inline-flex items-center gap-1"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Lihat Foto Uji</span>
              </button>
            </div>
          </div>

          {/* Parameter 2: Oksigen Terlarut (DO) */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-emerald-300 transition-colors flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-cyan-50 text-cyan-700 rounded-xl">
                    <Wind className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">Oksigen Terlarut (DO)</h3>
                    <p className="text-xs text-slate-500">Baku Mutu Minimum: ≥ 4.0 mg/L</p>
                  </div>
                </div>
                <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Baik (Optimal)
                </span>
              </div>

              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-4xl font-extrabold text-slate-900 font-mono">{current.do}</span>
                <span className="text-sm font-semibold text-slate-500">mg/L</span>
              </div>

              <p className="text-xs text-slate-600 mt-2">
                Kadar oksigen terlarut melimpah, mendukung kehidupan ikan Nilem, Tawes, dan mikroorganisme danau.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Aerasi Alami & Fitoremediasi</span>
              <span className="text-emerald-700 font-semibold">Tercukupi</span>
            </div>
          </div>

          {/* Parameter 3: Suhu Air */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-emerald-300 transition-colors flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-amber-50 text-amber-700 rounded-xl">
                    <Thermometer className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">Suhu Air Danau</h3>
                    <p className="text-xs text-slate-500">Normal Tropis: 22 – 28 °C</p>
                  </div>
                </div>
                <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Normal
                </span>
              </div>

              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-4xl font-extrabold text-slate-900 font-mono">{current.temp}</span>
                <span className="text-sm font-semibold text-slate-500">°C</span>
              </div>

              <p className="text-xs text-slate-600 mt-2">
                Suhu perairan terukur 27°C, dalam batas rentang normal optimal perairan danau tropis.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span>Kondisi Cuaca Lapangan:</span>
              <span className="text-slate-800 font-semibold">{current.weather}</span>
            </div>
          </div>

          {/* Parameter 4: Padatan Terlarut (TDS) & Kekeruhan */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm hover:border-emerald-300 transition-colors flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-teal-50 text-teal-700 rounded-xl">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 text-sm">TDS & Kekeruhan</h3>
                    <p className="text-xs text-slate-500">Baku Mutu TDS: &lt; 1000 ppm</p>
                  </div>
                </div>
                <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Baik (Rendah)
                </span>
              </div>

              <div className="flex items-baseline gap-3 mt-2">
                <div>
                  <span className="text-3xl font-extrabold text-slate-900 font-mono">{current.tds}</span>
                  <span className="text-xs font-semibold text-slate-500 ml-1">ppm</span>
                </div>
                <span className="text-slate-300">|</span>
                <div>
                  <span className="text-2xl font-bold text-slate-700 font-mono">{current.turbidity}</span>
                  <span className="text-xs font-semibold text-slate-500 ml-1">NTU</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 mt-2">
                Konsentrasi padatan terlarut rendah membuktikan efektivitas sistem penyaring sedimen dan tanaman riparian.
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500">Uji TDS-3 Meter</span>
              <button
                onClick={() => setShowPhotoModal('/images/measurement-tds.jpg')}
                className="text-emerald-700 font-semibold hover:underline inline-flex items-center gap-1"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Lihat Foto Uji</span>
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Catatan Lapangan & Bukti Foto Pengamatan */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Catatan Observasi Lapangan (Col 7) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Eye className="w-5 h-5 text-emerald-700" />
              <span>Catatan Observasi Lapangan Mandiri</span>
            </h3>
            <span className="text-xs text-emerald-800 font-semibold bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
              Data Terkini
            </span>
          </div>

          <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-xl p-4 text-xs sm:text-sm text-slate-700 leading-relaxed">
            <p className="font-medium text-emerald-950 mb-1">
              Ringkasan Kondisi Lapangan:
            </p>
            <p className="italic text-slate-700">
              &ldquo;{current.notes}&rdquo;
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Kondisi Aliran</span>
              <span className="font-bold text-slate-800">{current.flow}</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Cuaca Lapangan</span>
              <span className="font-bold text-slate-800">{current.weather}</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Kekeruhan Air</span>
              <span className="font-bold text-slate-800">{current.turbidity} NTU (Jernih)</span>
            </div>
            <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
              <span className="text-slate-400 block text-[10px] uppercase font-bold">Metode Pengujian</span>
              <span className="font-bold text-emerald-800">In-Situ Mandiri</span>
            </div>
          </div>
        </div>

        {/* Kartu Bukti Foto Lapangan (Col 5) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Camera className="w-4 h-4 text-emerald-700" />
              <span>Dokumentasi Uji Langsung di Air</span>
            </h3>
            <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              Foto Asli Pengamatan
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div 
              onClick={() => setShowPhotoModal('/images/measurement-ph.jpg')}
              className="group relative rounded-xl overflow-hidden border border-slate-200 cursor-pointer shadow-sm hover:shadow-md transition-all"
            >
              <img 
                src="/images/measurement-ph.jpg" 
                alt="Pengukuran pH meter langsung di air"
                className="w-full h-28 object-cover group-hover:scale-105 transition-transform duration-300" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-2">
                <span className="text-[10px] text-white font-bold leading-tight">Uji pH Meter In-Situ</span>
              </div>
            </div>

            <div 
              onClick={() => setShowPhotoModal('/images/measurement-tds.jpg')}
              className="group relative rounded-xl overflow-hidden border border-slate-200 cursor-pointer shadow-sm hover:shadow-md transition-all"
            >
              <img 
                src="/images/measurement-tds.jpg" 
                alt="Pengujian TDS-3 meter di air"
                className="w-full h-28 object-cover group-hover:scale-105 transition-transform duration-300" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex items-end p-2">
                <span className="text-[10px] text-white font-bold leading-tight">Uji TDS-3 Meter</span>
              </div>
            </div>
          </div>

          <p className="text-[11px] text-slate-500 leading-tight">
            Pemeriksaan fisik dan kimia dilakukan langsung pada perairan Ekoriparian Leuwi Padjadjaran oleh tim mahasiswa menggunakan alat ukur terkalibrasi.
          </p>
        </div>

      </div>

      {/* Tabel Riwayat Pembaruan Data Lapangan */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-slate-900 text-lg">
              Tabel Riwayat Data Pengamatan Lapangan
            </h3>
            <p className="text-xs text-slate-500">
              Log pengamatan kualitas air yang dihimpun tim survei mandiri Universitas Padjadjaran.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetData}
              title="Reset data ke bawaan"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-300 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Data Awal</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200">
              <tr>
                <th className="py-3 px-3.5">Waktu</th>
                <th className="py-3 px-3.5">Titik Pantau</th>
                <th className="py-3 px-3.5">pH</th>
                <th className="py-3 px-3.5">DO (mg/L)</th>
                <th className="py-3 px-3.5">Suhu (°C)</th>
                <th className="py-3 px-3.5">TDS (ppm)</th>
                <th className="py-3 px-3.5">Kekeruhan</th>
                <th className="py-3 px-3.5">Cuaca</th>
                <th className="py-3 px-3.5">Pencatat</th>
                <th className="py-3 px-3.5">Catatan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredRecords.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="py-3 px-3.5 font-semibold text-slate-900 whitespace-nowrap">{r.timestamp}</td>
                  <td className="py-3 px-3.5 font-medium text-emerald-800 whitespace-nowrap">{r.station}</td>
                  <td className="py-3 px-3.5 font-mono font-bold text-slate-900 bg-emerald-50/50">{r.ph}</td>
                  <td className="py-3 px-3.5 font-mono font-medium text-slate-700">{r.do}</td>
                  <td className="py-3 px-3.5 font-mono text-slate-700">{r.temp}°</td>
                  <td className="py-3 px-3.5 font-mono text-slate-700">{r.tds}</td>
                  <td className="py-3 px-3.5 font-mono text-slate-700">{r.turbidity} NTU</td>
                  <td className="py-3 px-3.5 text-slate-600 whitespace-nowrap">{r.weather}</td>
                  <td className="py-3 px-3.5 text-slate-700 whitespace-nowrap font-medium">{r.recorder}</td>
                  <td className="py-3 px-3.5 text-slate-500 max-w-xs truncate" title={r.notes}>{r.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Form Tambah Data Pengamatan Baru */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8 animate-fade-in">
            <div className="bg-emerald-900 text-white p-5 flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-lg">Input Data Pengamatan Lapangan</h3>
                <p className="text-xs text-emerald-200">Formulir pembaruan parameter kualitas air Ekoriparian Leuwi Padjadjaran</p>
              </div>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-emerald-300 hover:text-white p-1 rounded-lg hover:bg-emerald-800/80 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-6 space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-bold text-slate-800 mb-1">Titik Pantau / Lokasi Stasiun</label>
                <select
                  value={formData.station}
                  onChange={(e) => setFormData({ ...formData, station: e.target.value })}
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  required
                >
                  <option value="Stasiun 1 - Hulu (Area Konservasi Unpad)">Stasiun 1 - Hulu (Area Konservasi Unpad)</option>
                  <option value="Stasiun 2 - Tengah (Zona Edukasi & Fitoremediasi)">Stasiun 2 - Tengah (Zona Edukasi & Fitoremediasi)</option>
                  <option value="Stasiun 3 - Hilir (Outlet Danau & Sempadan Jembatan)">Stasiun 3 - Hilir (Outlet Danau & Sempadan Jembatan)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">Derajat Keasaman (pH)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="1"
                    max="14"
                    value={formData.ph}
                    onChange={(e) => setFormData({ ...formData, ph: parseFloat(e.target.value) || 0 })}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    required
                  />
                  <span className="text-[11px] text-slate-400">Baku mutu: 6.0 – 9.0</span>
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">Oksigen Terlarut (DO) mg/L</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="20"
                    value={formData.do}
                    onChange={(e) => setFormData({ ...formData, do: parseFloat(e.target.value) || 0 })}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    required
                  />
                  <span className="text-[11px] text-slate-400">Target minimum: ≥ 4.0 mg/L</span>
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">Suhu Air (°C)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="10"
                    max="45"
                    value={formData.temp}
                    onChange={(e) => setFormData({ ...formData, temp: parseFloat(e.target.value) || 0 })}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">TDS (ppm)</label>
                  <input
                    type="number"
                    step="1"
                    min="0"
                    max="5000"
                    value={formData.tds}
                    onChange={(e) => setFormData({ ...formData, tds: parseInt(e.target.value) || 0 })}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    required
                  />
                  <span className="text-[11px] text-slate-400">Maksimal: &lt; 1000 ppm</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">Kekeruhan (NTU)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="200"
                    value={formData.turbidity}
                    onChange={(e) => setFormData({ ...formData, turbidity: parseFloat(e.target.value) || 0 })}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">Kondisi Cuaca</label>
                  <select
                    value={formData.weather}
                    onChange={(e) => setFormData({ ...formData, weather: e.target.value })}
                    className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500 bg-white"
                  >
                    <option value="Cerah">Cerah</option>
                    <option value="Cerah Berawan">Cerah Berawan</option>
                    <option value="Mendung">Mendung</option>
                    <option value="Hujan Ringan">Hujan Ringan</option>
                    <option value="Hujan Deras">Hujan Deras</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">Nama Petugas / Tim Pengamat</label>
                <input
                  type="text"
                  value={formData.recorder}
                  onChange={(e) => setFormData({ ...formData, recorder: e.target.value })}
                  placeholder="Misal: Tim Pengamatan Mandiri Unpad"
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">Catatan Hasil Observasi Lapangan</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Catatan visual air, bau, keberadaan ikan atau tanaman air..."
                  className="w-full border border-slate-300 rounded-xl px-3.5 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                ></textarea>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-semibold hover:bg-slate-100 transition-colors cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold shadow-md transition-colors cursor-pointer"
                >
                  Simpan Data Lapangan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox / Foto Modal */}
      {showPhotoModal && (
        <div 
          onClick={() => setShowPhotoModal(null)}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 cursor-pointer"
        >
          <div className="relative max-w-2xl w-full bg-white rounded-2xl overflow-hidden shadow-2xl p-2" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setShowPhotoModal(null)}
              className="absolute top-4 right-4 z-10 bg-slate-900/70 hover:bg-slate-900 text-white p-1.5 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>
            <img 
              src={showPhotoModal} 
              alt="Dokumentasi Uji Lapangan" 
              className="w-full h-auto max-h-[80vh] object-contain rounded-xl"
            />
            <div className="p-3 text-center text-xs text-slate-600">
              Dokumentasi pengamatan mandiri langsung pada perairan Ekoriparian Leuwi Padjadjaran, Unpad Jatinangor.
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
