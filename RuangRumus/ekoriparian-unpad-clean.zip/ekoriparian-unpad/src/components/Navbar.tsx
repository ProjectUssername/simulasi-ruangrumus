import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Droplets, FlaskConical, Menu, X } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Beranda', path: '/' },
    { name: 'Sejarah & Latar Belakang', path: '/sejarah' },
    { name: 'Fungsi & Manfaat', path: '/fungsi' },
    { name: 'Pemantauan Kualitas Air', path: '/kualitas-air' },
    { name: 'Keanekaragaman Hayati', path: '/keanekaragaman-hayati' },
    { name: 'Panduan Kunjungan', path: '/panduan' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-emerald-950 border-b border-emerald-900 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo Branding */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 flex items-center justify-center text-white shadow-sm border border-emerald-600/60 group-hover:bg-emerald-600 transition-colors">
              <Droplets className="w-5 h-5 text-emerald-100" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white">
                  Leuwi Padjadjaran
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-900 text-emerald-300 border border-emerald-700">
                  Ekoriparian
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 font-normal hidden sm:block">
                Universitas Padjadjaran Jatinangor
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              const active = isActive(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors ${
                    active
                      ? 'text-white bg-emerald-900 border border-emerald-700'
                      : 'text-emerald-200 hover:text-white hover:bg-emerald-900/60'
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* Action Button */}
          <div className="hidden lg:flex items-center gap-3">
            <Link
              to="/kualitas-air"
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 shadow-sm transition-colors"
            >
              <FlaskConical className="w-3.5 h-3.5 text-emerald-950" />
              <span>Kualitas Air (pH 7.5)</span>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-xl text-emerald-200 hover:text-white hover:bg-emerald-900 focus:outline-none"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="lg:hidden bg-emerald-950 border-b border-emerald-900 px-4 pt-2 pb-6 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className={`block px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                isActive(link.path)
                  ? 'bg-emerald-900 text-white font-bold border border-emerald-700'
                  : 'text-emerald-200 hover:text-white hover:bg-emerald-900/50'
              }`}
            >
              {link.name}
            </Link>
          ))}
          <div className="pt-2">
            <Link
              to="/kualitas-air"
              onClick={() => setIsOpen(false)}
              className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-bold rounded-xl bg-emerald-500 text-emerald-950 shadow-sm"
            >
              <FlaskConical className="w-4 h-4" />
              <span>Data Kualitas Air Lapangan</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
