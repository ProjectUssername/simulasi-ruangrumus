import React from 'react';
import { ShieldAlert, Clock, MapPin, CheckCircle2 } from 'lucide-react';
import { VISITOR_GUIDELINES, EKORIPARIAN_INFO } from '../data/ekoparianData';

export const GuidelinesPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-20">
      
      {/* Header Banner */}
      <section className="bg-emerald-950 text-white py-14 relative overflow-hidden border-b border-emerald-900">
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-3">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900 text-emerald-200 text-xs font-semibold border border-emerald-800">
              <ShieldAlert className="w-3.5 h-3.5 text-emerald-300" />
              <span>Informasi Kunjungan Lapangan</span>
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Panduan & Tata Tertib Kunjungan
            </h1>
            <p className="text-emerald-100/90 text-sm sm:text-base leading-relaxed">
              Panduan etika observasi dan rekreasi publik untuk menjaga kebersihan perairan, kelestarian vegetasi fitoremediasi, dan kenyamanan lingkungan bersama di Danau Leuwi Padjadjaran.
            </p>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10">
        
        {/* Lokasi & Jam Operasional */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Clock className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Waktu Kunjungan Lapangan</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Terbuka untuk kegiatan riset mahasiswa, studi lingkungan, dan rekreasi sehat setiap hari:
            </p>
            <div className="bg-emerald-50/80 p-4 rounded-xl border border-emerald-200/80 space-y-1.5 font-sans text-xs text-emerald-950">
              <div className="flex items-center justify-between">
                <span className="font-semibold">Sesi Pagi:</span>
                <span className="font-mono font-bold">06:00 – 09:00 WIB</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-semibold">Sesi Sore:</span>
                <span className="font-mono font-bold">15:30 – 18:00 WIB</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-500">
              *Pengambilan sampel air untuk keperluan riset terjadwal dapat dikoordinasikan dengan pengelola sempadan kampus.
            </p>
          </div>

          <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
              <MapPin className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Lokasi & Akses Kawasan</h3>
            <p className="text-xs text-slate-600 leading-relaxed font-semibold text-slate-800">
              {EKORIPARIAN_INFO.location}
            </p>
            <div className="text-xs text-slate-600 bg-slate-50 p-3.5 rounded-xl border border-slate-200 leading-relaxed">
              Dapat diakses melalui jalan lingkar kampus ke arah Danau Universitas Padjadjaran Jatinangor (dekat area Fakultas Perikanan dan Ilmu Kelautan / FPIK). Fasilitas parkir tersedia di kantong parkir resmi kampus.
            </div>
          </div>

        </div>

        {/* Tata Tertib */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-emerald-700" />
              <span>Aturan & Etika Pengamatan Kawasan Ekoriparian</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Kepatuhan terhadap tata tertib menjaga data pengamatan kualitas air tetap murni dan melindungi biota danau.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {VISITOR_GUIDELINES.map((item, idx) => (
              <div key={idx} className="flex items-start gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="w-7 h-7 rounded-lg bg-emerald-800 text-white font-bold flex items-center justify-center shrink-0 text-xs">
                  {idx + 1}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 mb-0.5">{item.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </section>

    </div>
  );
};
