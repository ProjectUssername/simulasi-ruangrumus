import React from 'react';
import { Droplets, Trees, Fish, CheckCircle2, ShieldCheck, GraduationCap, HelpCircle } from 'lucide-react';
import { FUNCTIONS_LIST } from '../data/ekoparianData';

export const FunctionsPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-20">
      
      {/* Header Banner */}
      <section className="bg-emerald-950 text-white py-14 relative overflow-hidden border-b border-emerald-900">
        <div className="absolute inset-0 opacity-20">
          <img src="/images/hero-lake.jpg" alt="Danau Leuwi Padjadjaran" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-3">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900 text-emerald-200 text-xs font-semibold border border-emerald-800">
              <Droplets className="w-3.5 h-3.5 text-emerald-300" />
              <span>Pilar Keberlanjutan Perairan</span>
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Fungsi & Manfaat Ekoriparian Leuwi Padjadjaran
            </h1>
            <p className="text-emerald-100/90 text-sm sm:text-base leading-relaxed">
              Mengenal lebih dalam empat pilar utama ekoriparian: konservasi air alami, edukasi riset lapangan terbuka, rekreasi masyarakat, dan perlindungan keanekaragaman hayati akuatik.
            </p>
          </div>
        </div>
      </section>

      {/* Navigasi Cepat Modul Fungsi */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 relative z-10">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-200 grid grid-cols-2 md:grid-cols-4 gap-3">
          {FUNCTIONS_LIST.map((f, i) => (
            <a
              key={f.id}
              href={`#${f.id}`}
              className="p-3 rounded-xl bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-colors text-center group"
            >
              <span className="text-[10px] font-bold text-emerald-800 uppercase block mb-0.5">Pilar #0{i + 1}</span>
              <span className="text-xs font-bold text-slate-800 group-hover:text-emerald-950 leading-snug block">
                {f.title}
              </span>
            </a>
          ))}
        </div>
      </section>

      {/* Detail 4 Fungsi Utama */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
        {FUNCTIONS_LIST.map((func, index) => {
          const isEven = index % 2 === 0;

          return (
            <div
              key={func.id}
              id={func.id}
              className="scroll-mt-28 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center bg-white p-6 sm:p-10 rounded-2xl border border-slate-200 shadow-sm"
            >
              
              {/* Gambar / Visual */}
              <div className={`lg:col-span-5 ${!isEven ? 'lg:order-2' : ''}`}>
                <div className="relative rounded-2xl overflow-hidden shadow-sm border border-slate-200 group bg-slate-100">
                  <img
                    src={func.image}
                    alt={func.title}
                    className="w-full h-[320px] sm:h-[360px] object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-700 text-white inline-block mb-1">
                      Fungsi Terstruktur #{index + 1}
                    </span>
                    <h4 className="text-base font-bold text-white">{func.title}</h4>
                  </div>
                </div>
              </div>

              {/* Teks Penjelasan Detail */}
              <div className={`lg:col-span-7 space-y-4 ${!isEven ? 'lg:order-1' : ''}`}>
                <div className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full uppercase tracking-wider">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                  Keunggulan Ekologis
                </div>

                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
                  {func.title}
                </h2>

                <p className="text-slate-600 leading-relaxed text-sm">
                  {func.detailedDesc}
                </p>

                <div className="bg-slate-50 p-5 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Hasil & Dampak Nyata Lingkungan:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {func.highlights.map((hl, hIdx) => (
                      <div key={hIdx} className="flex items-start gap-2 text-xs text-slate-700">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        <span>{hl}</span>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

            </div>
          );
        })}
      </section>

      {/* Tanya Jawab Singkat Seputar Fungsi */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 bg-emerald-950 text-white rounded-2xl shadow-sm border border-emerald-900">
        <div className="text-center mb-8 space-y-1">
          <HelpCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
          <h3 className="text-xl font-bold">Prinsip Kerja Ekoriparian Leuwi Padjadjaran</h3>
          <p className="text-xs text-emerald-200">Bagaimana ekoriparian bekerja memulihkan perairan danau secara alami?</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-emerald-900/50 p-4 rounded-xl border border-emerald-800">
            <h4 className="font-bold text-emerald-200 mb-1">Fitoremediasi Tanaman Air</h4>
            <p className="text-emerald-100/90 leading-relaxed">
              Akar tanaman menyerap kelebihan nutrien (seperti nitrat dan fosfat) serta mengendapkan partikel sedimen tersuspensi secara gravitasi dan biologi.
            </p>
          </div>
          <div className="bg-emerald-900/50 p-4 rounded-xl border border-emerald-800">
            <h4 className="font-bold text-emerald-200 mb-1">Pengendalian Aliran & Erosi</h4>
            <p className="text-emerald-100/90 leading-relaxed">
              Jajaran bambu air dan pohon akar wangi (vetiver) menstabilkan tanah sempadan dari longsor dan menahan limpasan air hujan berkecepatan tinggi.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
