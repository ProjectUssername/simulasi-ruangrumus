import React from 'react';
import { Trees, Fish, ShieldCheck, Bug, CheckCircle2 } from 'lucide-react';
import { FLORA_LIST, FAUNA_LIST } from '../data/ekoparianData';

export const BiodiversityPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-20">
      
      {/* Header Banner */}
      <section className="bg-emerald-950 text-white py-14 relative overflow-hidden border-b border-emerald-900">
        <div className="absolute inset-0 opacity-20">
          <img src="/images/hero-lake.jpg" alt="Danau Leuwi Padjadjaran" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-3">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900 text-emerald-200 text-xs font-semibold border border-emerald-800">
              <Trees className="w-3.5 h-3.5 text-emerald-300" />
              <span>Ekosistem & Keanekaragaman Hayati</span>
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Keanekaragaman Hayati Leuwi Padjadjaran
            </h1>
            <p className="text-emerald-100/90 text-sm sm:text-base leading-relaxed">
              Kawasan Ekoriparian Leuwi Padjadjaran menjadi suaka pelestarian spesies vegetasi fitoremediasi serta habitat perlindungan ikan air tawar lokal dan bioindikator alami sempadan danau.
            </p>
          </div>
        </div>
      </section>

      {/* Grid Flora & Fitoremediasi */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-14">
        
        <div>
          <div className="mb-6 space-y-1">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest bg-emerald-100 px-3 py-1 rounded-full">
              Vegetasi Sempadan Air
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Flora & Tanaman Fitoremediasi
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm">
              Tanaman yang ditanam di sempadan air untuk menyerap zat pencemar, menahan erosi, dan menjaga kestabilan mikroklimat danau.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {FLORA_LIST.map((plant, index) => (
              <div key={index} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-800 bg-emerald-100 px-2.5 py-1 rounded-md">
                    {plant.category}
                  </span>
                  <Trees className="w-4 h-4 text-emerald-700" />
                </div>
                <h3 className="text-base font-bold text-slate-900">{plant.name}</h3>
                <p className="text-xs italic text-slate-500 font-mono mb-3">{plant.latinName}</p>
                <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <strong className="text-slate-800 block mb-0.5">Fungsi Ekologis:</strong>
                  {plant.role}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Grid Fauna & Ikan Air Tawar */}
        <div>
          <div className="mb-6 space-y-1">
            <span className="text-xs font-bold text-cyan-800 uppercase tracking-widest bg-cyan-100 px-3 py-1 rounded-full">
              Satwa & Spesies Akuatik
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Fauna & Ikan Air Tawar Leuwi Padjadjaran
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm">
              Spesies ikan lokal dan fauna sempadan yang berkembang biak dengan aman di kawasan konservasi danau.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {FAUNA_LIST.map((fauna, index) => (
              <div key={index} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-800 bg-cyan-100 px-2.5 py-1 rounded-md">
                      {fauna.status}
                    </span>
                    <Fish className="w-4 h-4 text-cyan-700" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900">{fauna.name}</h3>
                  <p className="text-xs italic text-slate-500 font-mono mb-2">{fauna.latinName}</p>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {fauna.description}
                  </p>
                </div>
                <div className="pt-3 border-t border-slate-100 flex items-center gap-1.5 text-[11px] text-emerald-700 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span>Habitat Terlindungi</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </section>

    </div>
  );
};
