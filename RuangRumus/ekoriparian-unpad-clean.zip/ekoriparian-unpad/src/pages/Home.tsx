import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Droplets, 
  History, 
  ArrowRight, 
  Trees, 
  Fish, 
  GraduationCap, 
  MapPin, 
  CheckCircle, 
  Camera, 
  FlaskConical, 
  Layers, 
  Users 
} from 'lucide-react';
import { EKORIPARIAN_INFO, FUNCTIONS_LIST, OBSERVATION_GALLERY } from '../data/ekoparianData';
import { WaterQualityWidget } from '../components/WaterQualityWidget';
import { FunctionCard } from '../components/FunctionCard';

export const Home: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      
      {/* Hero Section */}
      <section className="relative bg-emerald-950 text-white pt-14 pb-24 overflow-hidden border-b border-emerald-900">
        {/* Background Image Overlay with the real lake photo */}
        <div className="absolute inset-0 z-0 opacity-20">
          <img
            src="/images/hero-lake.jpg"
            alt="Danau Leuwi Padjadjaran Unpad"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-emerald-950 via-emerald-950/80 to-emerald-950/40"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-6">
            
            {/* Clean Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-900/80 border border-emerald-700/80 text-emerald-200 text-xs font-semibold">
              <Droplets className="w-3.5 h-3.5 text-emerald-300" />
              <span>Restorasi & Konservasi Air Kampus Unpad Jatinangor</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-[1.15] text-white">
              Ekoriparian <span className="text-emerald-300">Leuwi Padjadjaran</span>
            </h1>

            <p className="text-base sm:text-lg text-emerald-100/90 leading-relaxed font-normal">
              Kawasan restorasi ekosistem sempadan danau seluas <strong>800 m²</strong> di Universitas Padjadjaran Jatinangor. Memadukan teknologi fitoremediasi tanaman air alami, pemantauan kualitas air lapangan secara mandiri, konservasi biota akuatik, serta ruang terbuka hijau publik.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Link
                to="/kualitas-air"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-sm shadow-md transition-colors"
              >
                <FlaskConical className="w-4 h-4" />
                <span>Lihat Data Kualitas Air (pH 7.5)</span>
              </Link>

              <Link
                to="/fungsi"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-emerald-900/80 hover:bg-emerald-800 text-white font-semibold text-sm border border-emerald-700 transition-colors"
              >
                <span>4 Fungsi Ekologis</span>
                <ArrowRight className="w-4 h-4 text-emerald-300" />
              </Link>
            </div>

            {/* Metric Highlights */}
            <div className="pt-8 border-t border-emerald-900/90 grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="bg-emerald-900/50 p-4 rounded-xl border border-emerald-800/80">
                <div className="text-2xl font-black text-emerald-300 font-mono">800 m²</div>
                <div className="text-xs text-emerald-200/90 mt-0.5">Luas Restorasi Perairan</div>
              </div>
              <div className="bg-emerald-900/50 p-4 rounded-xl border border-emerald-800/80">
                <div className="text-2xl font-black text-emerald-300 font-mono">7.5 pH</div>
                <div className="text-xs text-emerald-200/90 mt-0.5">Derajat Keasaman Netral</div>
              </div>
              <div className="bg-emerald-900/50 p-4 rounded-xl border border-emerald-800/80 col-span-2 sm:col-span-1">
                <div className="text-2xl font-black text-emerald-300 font-mono">9 Juli 2024</div>
                <div className="text-xs text-emerald-200/90 mt-0.5">Diresmikan di Kampus Unpad</div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Bagian Informasi Air Interaktif (Sesuai Format https://sites.google.com/view/sistem-pemantauan-kualitas-air) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-20 mb-16">
        <WaterQualityWidget showFullTable={true} />
      </section>

      {/* Galeri Dokumentasi Pengamatan Sendiri di Lapangan */}
      <section className="py-16 bg-white border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full uppercase tracking-wider mb-2">
                <Camera className="w-3.5 h-3.5" /> Dokumentasi Primer
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                Dokumentasi Hasil Pengamatan Lapangan Mandiri
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
                Foto-foto asli pengamatan langsung yang diambil oleh tim mahasiswa saat melakukan pengujian kualitas air dan survei lingkungan di kawasan Ekoriparian Leuwi Padjadjaran.
              </p>
            </div>

            <Link
              to="/kualitas-air"
              className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-emerald-800 hover:text-emerald-900 shrink-0"
            >
              <span>Buka Log Pengamatan Lengkap</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {OBSERVATION_GALLERY.map((item) => (
              <div 
                key={item.id} 
                className="bg-slate-50 rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition-shadow group flex flex-col justify-between"
              >
                <div>
                  <div className="relative h-52 overflow-hidden bg-slate-200">
                    <img 
                      src={item.src} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-3 left-3">
                      <span className="bg-slate-900/85 backdrop-blur-sm text-white text-[10px] font-bold px-2.5 py-1 rounded-md">
                        {item.tag}
                      </span>
                    </div>
                  </div>
                  <div className="p-4 space-y-2">
                    <h3 className="font-bold text-slate-900 text-sm group-hover:text-emerald-800 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {item.caption}
                    </p>
                  </div>
                </div>

                <div className="px-4 pb-4 pt-1">
                  <div className="text-[11px] text-emerald-800 font-semibold flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Dokumentasi Nyata Mahasiswa</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Profil Kawasan Ekoriparian Leuwi Padjadjaran */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-6 space-y-5">
              <div className="inline-flex items-center gap-2 text-xs font-bold text-emerald-800 bg-emerald-100 px-3 py-1 rounded-full uppercase tracking-wider">
                <Trees className="w-3.5 h-3.5" /> Profil Kawasan Konservasi
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight">
                Mengenal Ekoriparian Leuwi Padjadjaran
              </h2>

              <p className="text-slate-600 text-sm leading-relaxed">
                <strong>Ekoriparian Leuwi Padjadjaran</strong> adalah fasilitas pemanfaatan dan penataan zona sempadan perairan danau di kampus Universitas Padjadjaran Jatinangor. Inisiatif ini memadukan pemulihan ekologis secara alami tanpa merusak struktur ekosistem perairan yang sudah ada.
              </p>

              <p className="text-slate-600 text-sm leading-relaxed">
                Sebelum ditata menjadi ekoriparian, zona tepi danau rentan terhadap erosi tebing dan peningkatan endapan lumpur akibat limpasan air hujan. Kawasan ini kini berfungsi optimal sebagai model konservasi danau kampus terpadu yang ramah lingkungan dan kaya fungsi edukatif.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="flex items-start gap-2.5 bg-white p-3.5 rounded-xl border border-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Teknologi Fitoremediasi</h4>
                    <p className="text-[11px] text-slate-500">Penyaringan alami menggunakan tanaman air khusus</p>
                  </div>
                </div>

                <div className="flex items-start gap-2.5 bg-white p-3.5 rounded-xl border border-slate-200">
                  <CheckCircle className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Habitat Ikan Air Tawar</h4>
                    <p className="text-[11px] text-slate-500">Suaka bagi ikan Nilem, Tawes, dan biota perairan</p>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <Link
                  to="/sejarah"
                  className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-emerald-800 hover:text-emerald-950"
                >
                  <span>Baca Sejarah & Latar Belakang Pembangunan</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>

            </div>

            <div className="lg:col-span-6">
              <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-white">
                <img
                  src="/images/boardwalk.jpg"
                  alt="Dermaga Kayu dan Sempadan Air Ekoriparian"
                  className="w-full h-[380px] object-cover"
                />
                <div className="p-4 bg-white border-t border-slate-100">
                  <div className="text-xs font-bold text-emerald-800">Infrastruktur Ramah Lingkungan</div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Jalur pejalan kaki kayu dan dermaga observasi di sempadan Danau Leuwi Padjadjaran, difoto saat observasi lapangan.
                  </p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 4 Fungsi Utama Ekoriparian */}
      <section className="py-16 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-2">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest bg-emerald-100 px-3 py-1 rounded-full">
              Pilar Keberlanjutan
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              4 Fungsi Utama Ekoriparian Leuwi Unpad
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Kawasan Ekoriparian Leuwi Padjadjaran menjalankan empat peran strategis untuk pemulihan air, sarana akademik, dan kenyamanan publik.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {FUNCTIONS_LIST.map((item, idx) => (
              <FunctionCard key={item.id} item={item} index={idx} />
            ))}
          </div>

        </div>
      </section>

      {/* Program Penanaman Pohon & Edukasi Lingkungan */}
      <section className="py-14 bg-emerald-900 text-white border-t border-emerald-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-3">
              <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-800 text-emerald-200 text-xs font-bold">
                <Trees className="w-3.5 h-3.5 text-emerald-300" /> Konservasi Daerah Tangkapan Air
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Penanaman Pohon Konservasi & Penebaran Eco-Enzyme
              </h2>
              <p className="text-emerald-100 text-xs sm:text-sm leading-relaxed">
                Di kawasan Ekoriparian Leuwi Padjadjaran, sivitas akademika Universitas Padjadjaran menanam puluhan pohon konservasi penahan erosi tebing serta secara berkala menyebarkan cairan olahan eco-enzyme untuk memulihkan mikroorganisme air dan menjaga stabilitas kualitas air danau.
              </p>
            </div>

            <div className="lg:col-span-4 flex justify-start lg:justify-end">
              <Link
                to="/fungsi#edukasi"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-emerald-950 hover:bg-emerald-50 font-bold text-xs sm:text-sm shadow-md transition-colors"
              >
                <span>Lihat Program Edukasi</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* CTA Panduan & Kunjungan */}
      <section className="py-14 bg-slate-50 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-2xl mx-auto space-y-4">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">Tertarik Berkunjung ke Leuwi Padjadjaran?</h2>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Ekoriparian Leuwi Padjadjaran terbuka untuk mahasiswa, peneliti, dan warga kampus yang ingin melakukan studi lingkungan maupun sekadar menikmati udara segar di pagi dan sore hari.
            </p>
            <div className="pt-2 flex flex-wrap justify-center gap-3">
              <Link
                to="/panduan"
                className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs sm:text-sm shadow-sm transition-colors"
              >
                Tata Tertib & Panduan Kunjungan
              </Link>
              <Link
                to="/keanekaragaman-hayati"
                className="px-5 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-bold text-xs sm:text-sm border border-slate-300 transition-colors"
              >
                Lihat Flora & Fauna Akuatik
              </Link>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
