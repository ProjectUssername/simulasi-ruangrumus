import React from 'react';
import { History, Calendar, Landmark, Award, ShieldCheck, ArrowRight } from 'lucide-react';
import { HISTORY_TIMELINE, EKORIPARIAN_INFO } from '../data/ekoparianData';
import { Link } from 'react-router-dom';

export const HistoryPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-20">
      
      {/* Header Banner */}
      <section className="bg-emerald-950 text-white py-14 relative overflow-hidden border-b border-emerald-900">
        <div className="absolute inset-0 opacity-20">
          <img src="/images/hero-lake.jpg" alt="Danau Leuwi Padjadjaran" className="w-full h-full object-cover" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-3">
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900 text-emerald-200 text-xs font-semibold border border-emerald-800">
              <History className="w-3.5 h-3.5 text-emerald-300" />
              <span>Latar Belakang & Sejarah Pembangunan</span>
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Sejarah Ekoriparian Leuwi Padjadjaran
            </h1>
            <p className="text-emerald-100/90 text-sm sm:text-base leading-relaxed">
              Perjalanan komitmen Universitas Padjadjaran merestorasi sempadan danau kampus menjadi ekoriparian percontohan seluas 800 m² untuk fungsi konservasi air dan laboratorium alam terbuka.
            </p>
          </div>
        </div>
      </section>

      {/* Ringkasan Fakta Sejarah */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 relative z-10">
        <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-200 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-bold uppercase">Tanggal Peresmian</div>
              <div className="text-lg font-black text-slate-900">{EKORIPARIAN_INFO.inaugurationDate}</div>
              <p className="text-xs text-slate-500 mt-1">Diresmikan di Kampus Unpad Jatinangor</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold shrink-0">
              <Landmark className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-bold uppercase">Luas & Nilai Bangunan</div>
              <div className="text-lg font-black text-slate-900">{EKORIPARIAN_INFO.areaSize} / {EKORIPARIAN_INFO.investmentValue}</div>
              <p className="text-xs text-slate-500 mt-1">Selesai dibangun awal tahun 2024</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center font-bold shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs text-slate-500 font-bold uppercase">Pencapaian Kunci</div>
              <div className="text-lg font-black text-slate-900">Ekoriparian Kampus #1</div>
              <p className="text-xs text-slate-500 mt-1">Model percontohan ekoriparian danau pertama di lingkungan perguruan tinggi</p>
            </div>
          </div>
        </div>
      </section>

      {/* Narasi Mengapa Dinamakan Leuwi Padjadjaran */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-5">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest bg-emerald-100 px-3 py-1 rounded-full">
              Asal-Usul & Latar Belakang
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Mengapa Menggunakan Nama &ldquo;Leuwi Padjadjaran&rdquo;?
            </h2>
            
            <p className="text-slate-600 text-sm leading-relaxed">
              Kata <strong>&ldquo;Leuwi&rdquo;</strong> berasal dari bahasa Sunda yang berarti <strong className="text-slate-900">&ldquo;lubuk atau bagian terdalam sungai/danau&rdquo;</strong>. Dalam tradisi Sunda tradisional, leuwi merupakan kawasan yang dihormati dan dijaga keberadaannya karena menjadi tempat berkumpulnya air jernih serta tempat berkembang biaknya berbagai spesies ikan air tawar.
            </p>

            <p className="text-slate-600 text-sm leading-relaxed">
              Penggunaan nama <strong>Leuwi Padjadjaran</strong> menegaskan komitmen Universitas Padjadjaran untuk mengembalikan fungsi luhur perairan tersebut — dari area sempadan danau yang rentan erosi menjadi laboratorium alam modern yang memadukan kearifan lokal Sunda dengan teknologi konservasi perairan fitoremediasi.
            </p>

            <div className="bg-emerald-50 p-5 rounded-2xl border border-emerald-200">
              <h4 className="font-bold text-emerald-900 text-sm mb-2 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700" /> Tantangan Lingkungan Sebelum Restorasi:
              </h4>
              <ul className="space-y-1.5 text-xs text-emerald-900">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span> Erosi tanah tepi danau akibat limpasan air hujan dari kawasan atas Jatinangor.
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span> Penumpukan sedimen lumpur yang menurunkan kedalaman efektif danau.
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span> Kurangnya vegetasi penangkap limbah organik di sekeliling air.
                </li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-white">
              <img
                src="/images/field-staff.jpg"
                alt="Observasi Lapangan Bersama Petugas"
                className="w-full h-[400px] object-cover"
              />
              <div className="p-4 bg-white border-t border-slate-100">
                <span className="text-[10px] font-bold uppercase tracking-widest bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded">
                  Aksi Nyata Kampus Hijau
                </span>
                <p className="text-sm font-bold text-slate-900 mt-1">Observasi Bersama Pengelola Lapangan</p>
                <p className="text-xs text-slate-600 mt-0.5">Diskusi dan pengamatan langsung kondisi sempadan danau Leuwi Padjadjaran.</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Timeline Perjalanan */}
      <section className="bg-slate-100 py-16 border-t border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-12 space-y-2">
            <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest bg-emerald-200/60 px-3 py-1 rounded-full">
              Linimasa Pembangunan
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              Jejak Langkah Restorasi Leuwi Padjadjaran
            </h2>
          </div>

          <div className="space-y-6">
            {HISTORY_TIMELINE.map((event, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col sm:flex-row items-start gap-4">
                <div className="shrink-0 bg-emerald-50 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-xl font-bold text-xs">
                  {event.year}
                </div>
                <div className="space-y-1.5 flex-grow">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                      {event.category}
                    </span>
                    <h3 className="text-base font-bold text-slate-900">{event.title}</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{event.description}</p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* Komitmen Riset & Konservasi Kampus */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-emerald-950 text-white rounded-2xl p-8 sm:p-12 shadow-md border border-emerald-900">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-3">
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                Komitmen Riset Lingkungan Universitas Padjadjaran
              </h2>
              <p className="text-emerald-100 text-xs sm:text-sm leading-relaxed">
                Ekoriparian Leuwi Padjadjaran merupakan wujud nyata integrasi riset ilmiah dan pengelolaan lingkungan kampus berkelanjutan. Fasilitas ini menjadi ruang terbuka bagi mahasiswa dan peneliti untuk melakukan pemantauan kualitas air mandiri, eksplorasi keanekaragaman hayati akuatik, serta program konservasi perairan terpadu.
              </p>
              <div className="pt-2 flex flex-wrap gap-2 text-xs text-emerald-200">
                <span className="bg-emerald-900 px-3 py-1 rounded-full border border-emerald-700">Sivitas Akademika Unpad</span>
                <span className="bg-emerald-900 px-3 py-1 rounded-full border border-emerald-700">Riset Terbuka & Pengamatan Mandiri</span>
                <span className="bg-emerald-900 px-3 py-1 rounded-full border border-emerald-700">Kampus Hijau Berkelanjutan</span>
              </div>
            </div>

            <div className="lg:col-span-4 flex justify-start lg:justify-end">
              <Link
                to="/kualitas-air"
                className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold text-xs sm:text-sm shadow-md transition-colors flex items-center gap-2"
              >
                <span>Lihat Data Kualitas Air (pH 7.5)</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

          </div>
        </div>
      </section>

    </div>
  );
};
