import React from 'react';
import { 
  Droplets, 
  FlaskConical, 
  Wind, 
  Thermometer, 
  Layers, 
  CheckCircle2, 
  HelpCircle, 
  FileText, 
  Camera, 
  Users, 
  MapPin 
} from 'lucide-react';
import { WaterQualityWidget } from '../components/WaterQualityWidget';
import { OBSERVATION_GALLERY } from '../data/ekoparianData';

export const WaterQualityPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 pb-20">
      
      {/* Header Banner */}
      <section className="bg-emerald-950 text-white py-14 border-b border-emerald-900 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-900 text-emerald-200 text-xs font-semibold border border-emerald-800">
              <Droplets className="w-3.5 h-3.5 text-emerald-300" />
              <span>Sistem Pemantauan Kualitas Air Danau</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
              Data Kualitas Air Ekoriparian Leuwi Padjadjaran
            </h1>
            <p className="text-emerald-100/90 text-sm sm:text-base leading-relaxed">
              Dokumentasi dan pencatatan parameter fisika-kimia perairan danau kampus Universitas Padjadjaran Jatinangor. Seluruh data disajikan secara transparan berdasarkan <strong>hasil pengamatan mandiri langsung di lapangan</strong>.
            </p>
          </div>
        </div>
      </section>

      {/* Main Monitoring Section (Widget with Station Filter, Key Metrics, Observation Notes, and Table) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 relative z-10 space-y-10">
        
        {/* The interactive widget that mirrors https://sites.google.com/view/sistem-pemantauan-kualitas-air */}
        <WaterQualityWidget showFullTable={true} />

        {/* Metodologi & Instrumen Pengamatan Lapangan */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-700" />
              <span>Metodologi & Alat Uji Pengamatan Mandiri</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Standar prosedur operasional pengujian parameter kualitas air in-situ oleh tim mahasiswa.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
                <FlaskConical className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Uji Derajat Keasaman (pH)</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pengukuran derajat keasaman dilakukan secara in-situ menggunakan <strong>digital pH meter</strong> yang dicelupkan langsung pada kedalaman 10–20 cm dari permukaan air danau. Hasil pengukuran menunjukkan nilai <strong>7.5</strong> (kategori normal dan stabil).
              </p>
              <div className="pt-2 text-[11px] font-semibold text-emerald-800">
                Rentang Optimal: 6.0 – 9.0
              </div>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-10 h-10 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center font-bold">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Uji Total Dissolved Solids (TDS)</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pengujian kandungan padatan terlarut menggunakan instrumen <strong>TDS-3 meter portabel</strong>. Pengukuran dilakukan pada titik aliran tenang untuk mengetahui konsentrasi mineral dan partikel terlarut dengan hasil rata-rata <strong>142 ppm</strong>.
              </p>
              <div className="pt-2 text-[11px] font-semibold text-emerald-800">
                Batas Aman: &lt; 1000 ppm
              </div>
            </div>

            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="w-10 h-10 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                <Thermometer className="w-5 h-5" />
              </div>
              <h3 className="font-bold text-slate-900 text-sm">Suhu & Pengamatan Fisik</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pencatatan suhu perairan danau (rata-rata <strong>27°C</strong>) serta evaluasi visual terhadap bau, kekeruhan, kecerahan penetrasi cahaya, dan kondisi vegetasi riparian (tanaman bambu air dan sempadan danau).
              </p>
              <div className="pt-2 text-[11px] font-semibold text-emerald-800">
                Kondisi Lapangan: Jernih & Tidak Berbau
              </div>
            </div>

          </div>
        </div>

        {/* Galeri Dokumentasi Pengamatan Sendiri di Lapangan */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <Camera className="w-5 h-5 text-emerald-700" />
                <span>Dokumentasi Pengamatan Lapangan Mandiri</span>
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Foto-foto asli kegiatan pengamatan dan pengukuran kualitas air di Ekoriparian Leuwi Padjadjaran.
              </p>
            </div>
            <span className="text-xs font-semibold px-3 py-1 bg-emerald-50 text-emerald-800 rounded-full border border-emerald-200 self-start sm:self-auto">
              Dokumentasi Primer
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {OBSERVATION_GALLERY.map((item) => (
              <div key={item.id} className="group bg-slate-50 rounded-xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="relative h-48 overflow-hidden bg-slate-200">
                  <img 
                    src={item.src} 
                    alt={item.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 left-2">
                    <span className="bg-slate-900/80 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-0.5 rounded">
                      {item.tag}
                    </span>
                  </div>
                </div>
                <div className="p-4 space-y-1.5">
                  <h3 className="font-bold text-slate-900 text-sm group-hover:text-emerald-800 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.caption}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </section>

    </div>
  );
};
