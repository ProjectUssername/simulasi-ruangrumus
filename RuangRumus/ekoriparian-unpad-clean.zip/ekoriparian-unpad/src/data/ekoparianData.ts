import { HistoryEvent, FunctionModule, PlantFlora, FishFauna, WaterQualityData, WaterQualityRecord } from '../types';

export const EKORIPARIAN_INFO = {
  name: 'Ekoriparian Leuwi Padjadjaran',
  fullName: 'Ekoriparian Leuwi Padjadjaran - Universitas Padjadjaran Jatinangor',
  location: 'Sempadan Danau Kampus Unpad, Jatinangor, Kabupaten Sumedang, Jawa Barat',
  areaSize: '800 m²',
  inaugurationDate: '9 Juli 2024',
  inauguratedBy: 'Pimpinan Universitas Padjadjaran & Tim Peneliti Lingkungan',
  investmentValue: 'Rp 1,4 Miliar',
  partners: ['Universitas Padjadjaran (Unpad)', 'Sivitas Akademika & Peneliti Kampus', 'Masyarakat & Komunitas Lingkungan'],
  tagline: 'Harmoni Air, Kampus, dan Ekosistem Berkelanjutan',
  summary: 'Fasilitas ekoriparian percontohan berbasis danau/setu pertama di lingkungan kampus Indonesia, dirancang untuk merestorasi kualitas air danau, melestarikan ekosistem perairan, serta menyediakan sarana riset edukasi dan ruang terbuka hijau publik.',
};

export const WATER_QUALITY_CURRENT: WaterQualityData = {
  timestamp: 'Pengamatan Lapangan Mandiri',
  ph: 7.5,
  tds: 142,
  do: 6.8,
  turbidity: 9.5,
  temperature: 27,
  status: 'Baik',
};

export const DEFAULT_WATER_RECORDS: WaterQualityRecord[] = [
  {
    id: 1,
    timestamp: 'Pengamatan Lapangan',
    station: 'Stasiun 1 - Hulu (Area Konservasi Unpad)',
    ph: 7.5,
    do: 6.8,
    temp: 27,
    turbidity: 9.5,
    tds: 142,
    weather: 'Cerah Berawan',
    flow: 'Tenang / Normal',
    recorder: 'Tim Pengamatan Mandiri Unpad',
    notes: 'Pengukuran in-situ mandiri. Air jernih, pH netral 7.5 terukur menggunakan pH meter digital. Suhu air normal 27°C. Vegetasi riparian di sempadan air rimbun, terlihat capung dan ikan kecil aktif.',
    photoUrl: '/images/measurement-ph.jpg'
  },
  {
    id: 2,
    timestamp: 'Pengamatan Lapangan',
    station: 'Stasiun 2 - Tengah (Zona Edukasi & Fitoremediasi)',
    ph: 7.4,
    do: 6.3,
    temp: 27,
    turbidity: 14.0,
    tds: 165,
    weather: 'Cerah Berawan',
    flow: 'Tenang / Normal',
    recorder: 'Tim Pengamatan Mandiri Unpad',
    notes: 'Air cukup jernih, tanaman fitoremediasi di sekitar zona biofilter tumbuh sehat. Suhu perairan 27°C. Pengujian TDS menunjukkan 165 ppm (kategori baik).',
    photoUrl: '/images/measurement-tds.jpg'
  },
  {
    id: 3,
    timestamp: 'Pengamatan Lapangan',
    station: 'Stasiun 3 - Hilir (Outlet Danau & Sempadan Jembatan)',
    ph: 7.2,
    do: 5.5,
    temp: 27,
    turbidity: 22.0,
    tds: 210,
    weather: 'Cerah Berawan',
    flow: 'Lambat',
    recorder: 'Tim Pengamatan Mandiri Unpad',
    notes: 'Kekeruhan sedikit meningkat di dekat outlet akibat sedimen aliran tanah permukaan. Suhu 27°C, nilai pH dan TDS tetap dalam batas aman baku mutu perairan.',
    photoUrl: '/images/boardwalk.jpg'
  },
  {
    id: 4,
    timestamp: 'Pengamatan Lapangan',
    station: 'Stasiun 1 - Hulu (Area Konservasi Unpad)',
    ph: 7.5,
    do: 6.9,
    temp: 27,
    turbidity: 10.2,
    tds: 138,
    weather: 'Cerah',
    flow: 'Tenang / Normal',
    recorder: 'Tim Pengamatan Mandiri Unpad',
    notes: 'Kondisi air stabil di area hulu konservasi. Suhu air 27°C, parameter pH konsisten di 7.5, tidak ada bau atau buangan limbah terdeteksi.',
    photoUrl: '/images/team-observation.jpg'
  },
  {
    id: 5,
    timestamp: 'Pengamatan Lapangan',
    station: 'Stasiun 2 - Tengah (Zona Edukasi & Fitoremediasi)',
    ph: 7.3,
    do: 6.1,
    temp: 27,
    turbidity: 15.5,
    tds: 172,
    weather: 'Mendung',
    flow: 'Tenang / Normal',
    recorder: 'Tim Pengamatan Mandiri Unpad',
    notes: 'Observasi bersama pengelola lapangan. Suhu air 27°C. Sistem penyaring sedimen alami bekerja efektif menahan lumpur limpasan hujan.',
    photoUrl: '/images/field-staff.jpg'
  }
];

export const WATER_QUALITY_HISTORY: WaterQualityData[] = [
  { timestamp: '06:00', ph: 7.4, tds: 138, do: 6.6, turbidity: 9.0, temperature: 26.8, status: 'Baik' },
  { timestamp: '08:00', ph: 7.5, tds: 142, do: 6.8, turbidity: 9.5, temperature: 27.0, status: 'Baik' },
  { timestamp: '10:00', ph: 7.5, tds: 145, do: 6.9, turbidity: 9.8, temperature: 27.2, status: 'Baik' },
  { timestamp: '12:00', ph: 7.6, tds: 150, do: 6.7, turbidity: 10.2, temperature: 27.5, status: 'Baik' },
  { timestamp: '14:00', ph: 7.5, tds: 147, do: 6.5, turbidity: 10.0, temperature: 27.3, status: 'Baik' },
  { timestamp: '16:00', ph: 7.4, tds: 140, do: 6.6, turbidity: 9.2, temperature: 27.0, status: 'Baik' },
];

export const OBSERVATION_GALLERY = [
  {
    id: 'ph-meter',
    src: '/images/measurement-ph.jpg',
    title: 'Pengukuran Derajat Keasaman (pH) Air',
    caption: 'Pengujian in-situ langsung di perairan danau menggunakan pH meter digital dengan hasil terukur 7.5 (kategori netral/optimal).',
    tag: 'Pengukuran In-Situ'
  },
  {
    id: 'tds-meter',
    src: '/images/measurement-tds.jpg',
    title: 'Pengujian Total Dissolved Solids (TDS)',
    caption: 'Pemeriksaan kandungan padatan terlarut menggunakan TDS-3 meter untuk mengetahui konsentrasi mineral dan partikel terlarut.',
    tag: 'Pengujian In-Situ'
  },
  {
    id: 'team-observation',
    src: '/images/team-observation.jpg',
    title: 'Tim Pengamatan Mandiri Lapangan',
    caption: 'Mahasiswa peneliti dengan peralatan uji portabel (digital pH meter dan TDS tester) saat survei kualitas air di kawasan Ekoriparian.',
    tag: 'Tim Pengamat'
  },
  {
    id: 'boardwalk',
    src: '/images/boardwalk.jpg',
    title: 'Jembatan & Dermaga Pengamatan Danau',
    caption: 'Jalur kayu pengamatan di atas perairan sempadan danau Leuwi Padjadjaran yang digunakan sebagai titik observasi visual perairan.',
    tag: 'Area Observasi'
  },
  {
    id: 'field-staff',
    src: '/images/field-staff.jpg',
    title: 'Observasi Bersama Pengelola Lapangan',
    caption: 'Sesi koordinasi dan diskusi lapangan bersama petugas kebersihan dan perawatan kawasan sempadan danau Unpad.',
    tag: 'Koordinasi Lapangan'
  },
  {
    id: 'team-members',
    src: '/images/team-members.jpg',
    title: 'Dokumentasi Survei Sempadan Air',
    caption: 'Pengamatan kondisi vegetasi riparian dan batas penyangga danau oleh tim pengamat mandiri mahasiswa.',
    tag: 'Survei Lapangan'
  },
  {
    id: 'hero-lake',
    src: '/images/hero-lake.jpg',
    title: 'Lanskap Danau Leuwi Padjadjaran',
    caption: 'Panorama perairan terbuka danau Leuwi Padjadjaran dengan vegetasi pelindung danau dan perahu pemantauan di kejauhan.',
    tag: 'Lanskap Danau'
  }
];

export const HISTORY_TIMELINE: HistoryEvent[] = [
  {
    year: '2022 - 2023',
    title: 'Inisiasi & Riset Restorasi Danau Kampus',
    category: 'Pra-Pembangunan',
    description: 'Riset awal kualitas air danau kawasan Unpad Jatinangor serta rancangan pemulihan ekosistem sempadan perairan oleh tim peneliti dan akademisi Universitas Padjadjaran.',
  },
  {
    year: 'Awal 2024',
    title: 'Pembangunan Infrastruktur Ekologis',
    category: 'Pengembangan',
    description: 'Pembangunan fisik di area perairan seluas 800 m², meliputi kolam fitoremediasi tanaman air, biofilter penyaring sedimen, dermaga pandang kayu ramah lingkungan, serta jalur pejalan kaki sempadan.',
  },
  {
    year: '9 Juli 2024',
    title: 'Peresmian Ekoriparian Leuwi Padjadjaran',
    category: 'Peresmian',
    description: 'Diresmikan oleh Pimpinan Universitas Padjadjaran sebagai fasilitas ekoriparian danau percontohan kampus pertama di Indonesia untuk fungsi konservasi air, edukasi, dan riset terbuka.',
  },
  {
    year: 'Akhir 2024',
    title: 'Penanaman Pohon Konservasi & Penebaran Eco-Enzyme',
    category: 'Program',
    description: 'Penanaman puluhan pohon konservasi penahan erosi tebing danau serta penuangan berkala eco-enzyme untuk menutrisi mikroorganisme pengurai dan menjaga kestabilan oksigen terlarut.',
  },
  {
    year: '2025 - Sekarang (2026)',
    title: 'Pusat Riset Terbuka & Pengamatan Mandiri Mahasiswa',
    category: 'Program',
    description: 'Dimanfaatkan aktif sebagai sarana observasi kualitas air lapangan, penelitian keanekaragaman hayati akuatik, serta ruang terbuka hijau edukatif bagi civitas kampus dan publik.',
  },
];

export const FUNCTIONS_LIST: FunctionModule[] = [
  {
    id: 'konservasi',
    title: 'Restorasi & Konservasi Sumber Daya Air',
    iconName: 'Droplets',
    shortDesc: 'Menyaring polutan air danau secara alami dengan vegetasi akuatik dan biofilter pengendap.',
    detailedDesc: 'Ekoriparian Leuwi Padjadjaran berfungsi melindungi perairan danau kampus melalui proses fitoremediasi alami. Tanaman air seperti bambu air, melati air, dan akar wangi mengendapkan lumpur suspensi serta menyerap senyawa organik sebelum air mengalir lebih jauh.',
    highlights: [
      'Menstabilkan pH air danau pada kisaran netral (7.2 - 7.6)',
      'Mengurangi lumpur sedimentasi dan kekeruhan air',
      'Mempertahankan zona resapan alami air tanah kampus',
      'Penyangga tebing danau dari erosi akibat limpasan hujan deras',
    ],
    image: '/images/hero-lake.jpg',
    color: 'emerald',
  },
  {
    id: 'edukasi',
    title: 'Edukasi Lingkungan & Pengamatan Mandiri',
    iconName: 'GraduationCap',
    shortDesc: 'Laboratorium alam outdoor bagi mahasiswa untuk pengujian parameter air dan survei keanekaragaman hayati.',
    detailedDesc: 'Menjadi wadah riset langsung bagi mahasiswa Universitas Padjadjaran. Mahasiswa melakukan pengamatan in-situ mandiri untuk mengukur derajat keasaman (pH), kadar padatan terlarut (TDS), suhu, hingga kekeruhan air dengan alat ukur portabel.',
    highlights: [
      'Praktik langsung pengujian kualitas air menggunakan pH & TDS meter',
      'Pengamatan vegetasi riparian dan bioindikator air bersih',
      'Penyusunan data riwayat kualitas air danau secara berkala',
      'Sarana literasi ekologi perairan bagi mahasiswa dan masyarakat',
    ],
    image: '/images/team-observation.jpg',
    color: 'blue',
  },
  {
    id: 'rekreasi',
    title: 'Rekreasi Hijau & Ruang Terbuka Publik',
    iconName: 'Trees',
    shortDesc: 'Ruang Terbuka Hijau (RTH) yang asri dan sejuk untuk berolahraga, bersantai, dan menikmati panorama danau.',
    detailedDesc: 'Menyuguhkan suasana tenang di tepian danau kampus Unpad Jatinangor. Dilengkapi jalur jalan santai tepi air, dermaga kayu bercabang, serta pemandangan perairan terbuka yang menyegarkan pikiran.',
    highlights: [
      'Jalur pedestrian kayu di atas perairan sempadan danau',
      'Spot foto asri dengan latar pemandangan danau Unpad',
      'Mikroklimat sejuk dengan pepohonan pelindung yang rimbun',
      'Suasana damai untuk interaksi sosial dan kegiatan santai warga kampus',
    ],
    image: '/images/boardwalk.jpg',
    color: 'teal',
  },
  {
    id: 'biodiversitas',
    title: 'Perlindungan Keanekaragaman Hayati Akuatik',
    iconName: 'Fish',
    shortDesc: 'Habitat perlindungan spesies ikan air tawar, serangga bioindikator, dan burung sempadan danau.',
    detailedDesc: 'Menjaga keberlangsungan hidup biota air dan sempadan. Perairan danau yang terjaga kualitasnya menjadi rumah yang aman bagi ikan air tawar, capung jarum penanda air bersih, serta burung air lokal yang mencari makan.',
    highlights: [
      'Habitat ikan air tawar lokal (Nilem, Tawes, dan ikan pembersih)',
      'Keberadaan capung jarum dan capung raja sebagai bioindikator alami',
      'Vegetasi tepi air sebagai sarang dan tempat bertengger burung liar',
      'Pohon konservasi penahan erosi tebing danau',
    ],
    image: '/images/field-staff.jpg',
    color: 'cyan',
  },
];

export const FLORA_LIST: PlantFlora[] = [
  { name: 'Pohon Vetiver / Akar Wangi', latinName: 'Chrysopogon zizanioides', category: 'Penahan Erosi', role: 'Mencegah longsor tebing danau & menyaring logam berat' },
  { name: 'Bambu Air', latinName: 'Equisetum hyemale', category: 'Fitoremediasi', role: 'Menyerap polutan organik dan menjernihkan air' },
  { name: 'Melati Air', latinName: 'Echinodorus palaefolius', category: 'Vegetasi Aquatik', role: 'Pemasok oksigen terlarut dan estetika sempadan' },
  { name: 'Pohon Pulai', latinName: 'Alstonia scholaris', category: 'Pohon Pelindung', role: 'Penyerap karbon tinggi & peneduh alami kawasan' },
  { name: 'Pohon Bisbul & Gandaria', latinName: 'Diospyros blancoi', category: 'Buah Konservasi', role: 'Penyedia pakan satwa dan burung sempadan danau' },
];

export const FAUNA_LIST: FishFauna[] = [
  { name: 'Ikan Nilem', latinName: 'Osteochilus hasselti', status: 'Asli Citarum', description: 'Ikan pemakan plankton dan perifiton yang efektif membersihkan lumut dan alga air.' },
  { name: 'Ikan Tawes', latinName: 'Barbonymus gonionotus', status: 'Asli Citarum', description: 'Spesies herbivora penghuni danau dan sungai yang menjaga keseimbangan tanaman air.' },
  { name: 'Ikan Lalawak', latinName: 'Barbonymus balleroides', status: 'Restorasi', description: 'Ikan lokal air tawar yang habitatnya dilindungi di zona perairan tenang Leuwi Unpad.' },
  { name: 'Capung Jarum & Capung Raja', latinName: 'Odonata order', status: 'Dipertahankan', description: 'Bioindikator kemurnian udara dan kualitas air yang bersih dan bebas pencemaran berlebih.' },
];

export const VISITOR_GUIDELINES = [
  { title: 'Jaga Kebersihan', desc: 'Dilarang membuang sampah dalam bentuk apapun ke dalam danau atau area ekoriparian.' },
  { title: 'Dilarang Memancing Bebas', desc: 'Kawasan ini merupakan area perlindungan biota dan riset perairan kampus. Memancing hanya diizinkan untuk studi terjadwal.' },
  { title: 'Jaga Ketenangan Satwa', desc: 'Pertahankan suasana alami agar tidak mengganggu burung liar dan fauna yang bersarang.' },
  { title: 'Gunakan Jalur Pedestrian', desc: 'Berjalanlah pada jalur kayu yang disediakan agar tidak merusak vegetasi fitoremediasi tepi air.' },
];
