import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { HistoryPage } from './pages/HistoryPage';
import { FunctionsPage } from './pages/FunctionsPage';
import { WaterQualityPage } from './pages/WaterQualityPage';
import { BiodiversityPage } from './pages/BiodiversityPage';
import { GuidelinesPage } from './pages/GuidelinesPage';

// Scroll to top on page navigation
const ScrollToTop = () => {
  const { pathname } = useLocation();
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

export function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen bg-slate-50 font-sans antialiased text-slate-900 selection:bg-emerald-500 selection:text-white">
        <Navbar />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sejarah" element={<HistoryPage />} />
            <Route path="/fungsi" element={<FunctionsPage />} />
            <Route path="/kualitas-air" element={<WaterQualityPage />} />
            <Route path="/keanekaragaman-hayati" element={<BiodiversityPage />} />
            <Route path="/panduan" element={<GuidelinesPage />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
