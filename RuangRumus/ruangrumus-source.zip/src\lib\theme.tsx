'use client'
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

export type ColorModePreference = 'system' | 'light' | 'dark'
export type ResolvedColorMode = 'light' | 'dark'

interface ColorModeContextType {
  mode: ColorModePreference
  resolvedMode: ResolvedColorMode
  setMode: (mode: ColorModePreference) => void
  toggleMode: () => void
}

const STORAGE_KEY = 'ruangrumus_color_mode'

const ColorModeContext = createContext<ColorModeContextType>({
  mode: 'system',
  resolvedMode: 'light',
  setMode: () => {},
  toggleMode: () => {},
})

function getSystemMode(): ResolvedColorMode {
  if (typeof window === 'undefined') return 'light'
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
}

export function ColorModeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<ColorModePreference>('system')
  const [resolvedMode, setResolvedMode] = useState<ResolvedColorMode>('light')
  const [mounted, setMounted] = useState(false)

  // Initialize from localStorage or fallback to system
  useEffect(() => {
    setMounted(true)
    try {
      const saved = localStorage.getItem(STORAGE_KEY) as ColorModePreference | null
      if (saved && (saved === 'light' || saved === 'dark' || saved === 'system')) {
        setModeState(saved)
        const resolved = saved === 'system' ? getSystemMode() : saved
        setResolvedMode(resolved)
        document.documentElement.setAttribute('data-color-mode', resolved)
      } else {
        const sys = getSystemMode()
        setResolvedMode(sys)
        document.documentElement.setAttribute('data-color-mode', sys)
      }
    } catch {
      // localStorage may fail in restricted sandboxes
      const sys = getSystemMode()
      setResolvedMode(sys)
      document.documentElement.setAttribute('data-color-mode', sys)
    }
  }, [])

  // Listen to system preference changes when in 'system' mode
  useEffect(() => {
    if (!mounted || typeof window === 'undefined') return
    const mq = window.matchMedia('(prefers-color-scheme: dark)')
    const handler = (e: MediaQueryListEvent) => {
      if (mode === 'system') {
        const next = e.matches ? 'dark' : 'light'
        setResolvedMode(next)
        document.documentElement.setAttribute('data-color-mode', next)
      }
    }
    mq.addEventListener('change', handler)
    return () => mq.removeEventListener('change', handler)
  }, [mode, mounted])

  const setMode = (newMode: ColorModePreference) => {
    setModeState(newMode)
    try {
      localStorage.setItem(STORAGE_KEY, newMode)
    } catch {}

    const nextResolved = newMode === 'system' ? getSystemMode() : newMode
    setResolvedMode(nextResolved)
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-color-mode', nextResolved)
    }
  }

  const toggleMode = () => {
    // When toggling, switch between explicit light and dark
    const next = resolvedMode === 'dark' ? 'light' : 'dark'
    setMode(next)
  }

  return (
    <ColorModeContext.Provider value={{ mode, resolvedMode, setMode, toggleMode }}>
      {children}
    </ColorModeContext.Provider>
  )
}

export function useColorMode() {
  return useContext(ColorModeContext)
}
