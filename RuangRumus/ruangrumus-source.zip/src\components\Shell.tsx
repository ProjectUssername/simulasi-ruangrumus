'use client'
import { useEffect, useState } from 'react'
import {
  ArrowUpRight,
  Award,
  BookOpen,
  Check,
  ChevronDown,
  ChevronRight,
  FileText,
  GraduationCap,
  HardDrive,
  Home,
  Lightbulb,
  Menu,
  Moon,
  PenTool,
  Sparkles,
  Sun,
  UserRound,
  X,
} from 'lucide-react'
import { Link, subjectRoute, useRoute } from '../lib/navigation'
import { useStudy } from '../lib/study-store'
import { useColorMode } from '../lib/theme'
import { Dialog } from './Dialog'

export function Logo({ small = false }: { small?: boolean }) {
  return (
    <span className={'brand ' + (small ? 'brand-small' : '')}>
      <svg width={small ? '28' : '34'} height={small ? '28' : '34'} viewBox="0 0 40 40" fill="none" aria-hidden="true">
        <path d="M1 12 19 3l18 9-18 9z" fill="var(--theme-color, #3766df)" />
        <path d="m1 16 18 9 18-9v6l-18 9-18-9z" fill="var(--theme-dark, #234fc3)" />
        <path d="m1 26 18 9 18-9v4l-18 9-18-9z" fill="var(--theme-border, #73a0fb)" />
        <path d="m19 3 18 9-18 9z" fill="var(--theme-color, #477ff1)" />
      </svg>
      <span>
        Ruang<span className="brand-second">Rumus</span>
      </span>
    </span>
  )
}

export function Header() {
  const { path, currentSubject, currentSection, isRootHome, allSubjects } = useRoute()
  const { state, setName, ready } = useStudy()
  const { mode, resolvedMode, setMode, toggleMode } = useColorMode()
  const [menu, setMenu] = useState(false)
  const [profile, setProfile] = useState(false)
  const [subjectDropdown, setSubjectDropdown] = useState(false)
  const [name, setDraft] = useState('')

  // Close menus on Escape key
  useEffect(() => {
    if (!menu && !subjectDropdown) return
    const close = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setMenu(false)
        setSubjectDropdown(false)
      }
    }
    window.addEventListener('keydown', close)
    return () => window.removeEventListener('keydown', close)
  }, [menu, subjectDropdown])

  // Prevent background body scroll when mobile menu is open
  useEffect(() => {
    if (typeof document === 'undefined') return
    if (menu) {
      const originalOverflow = document.body.style.overflow
      document.body.style.overflow = 'hidden'
      return () => {
        document.body.style.overflow = originalOverflow
      }
    }
  }, [menu])

  const slug = currentSubject.slug
  const navRoutes: [string, string, typeof Home][] = [
    [isRootHome ? '/' : subjectRoute(slug), 'Beranda', Home],
    [subjectRoute(slug, 'materi'), 'Materi Konsep', BookOpen],
    [subjectRoute(slug, 'contoh-soal'), 'Contoh Soal', FileText],
    [subjectRoute(slug, 'cara-pengerjaan'), 'Cara Pengerjaan', Lightbulb],
    [subjectRoute(slug, 'try-out'), 'Simulasi Try Out', PenTool],
    [subjectRoute(slug, 'hasil'), 'Hasil Belajar', Award],
  ]

  if (currentSubject.practiceRubric) {
    navRoutes.push([subjectRoute(slug, 'praktik'), 'Penilaian Praktik', Sparkles])
  }

  const isNavActive = (url: string) => {
    if (url === '/' && path === '/') return true
    if (url !== '/' && path.startsWith(url)) return true
    if (url.endsWith('/' + currentSection)) return true
    return false
  }

  return (
    <>
      <header className="site-header">
        <div className="header-inner">
          <div className="header-left">
            <Link href="/" aria-label="RuangRumus, beranda" onClick={() => setMenu(false)}>
              <Logo />
            </Link>

            {/* Desktop Subject Switcher Pill */}
            <div className="subject-switcher-dropdown desktop-only">
              <button
                type="button"
                className="subject-badge-pill"
                onClick={() => setSubjectDropdown(!subjectDropdown)}
                aria-expanded={subjectDropdown}
                aria-label="Pilih mata pelajaran"
              >
                <GraduationCap size={14} />
                <span>{currentSubject.name}</span>
                <ChevronDown size={12} />
              </button>

              {subjectDropdown && (
                <div className="subject-switcher-menu" role="menu">
                  <div className="subject-switcher-title">
                    Pilih Mata Pelajaran
                  </div>
                  {allSubjects.map((sub) => (
                    <Link
                      key={sub.id}
                      href={subjectRoute(sub.slug)}
                      className={'subject-switcher-item ' + (sub.slug === slug ? 'active' : '')}
                      role="menuitem"
                      onClick={() => setSubjectDropdown(false)}
                    >
                      <span className="flex items-center gap-2">
                        <span className={'subject-color-dot dot-' + sub.theme} />
                        <span>{sub.name}</span>
                      </span>
                      {sub.slug === slug && <Check size={14} />}
                    </Link>
                  ))}
                  <div className="subject-switcher-divider">
                    <Link
                      href="/"
                      className="subject-switcher-item"
                      role="menuitem"
                      onClick={() => setSubjectDropdown(false)}
                    >
                      <span style={{ color: 'var(--muted)', fontSize: '12px' }}>Katalog Semua Mapel</span>
                      <ArrowUpRight size={13} style={{ color: 'var(--muted)' }} />
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>

          <nav className="desktop-nav" aria-label="Navigasi utama">
            {navRoutes.map(([url, label]) => (
              <Link
                key={url}
                href={url}
                aria-current={isNavActive(url) ? 'page' : undefined}
                className={isNavActive(url) ? 'nav-active' : ''}
              >
                {label}
              </Link>
            ))}
          </nav>

          <div className="header-tools">
            {/* Quick Dark/Light Theme Toggle */}
            <button
              type="button"
              className="theme-toggle-btn icon-btn"
              onClick={toggleMode}
              title={resolvedMode === 'dark' ? 'Ganti ke mode terang' : 'Ganti ke mode gelap'}
              aria-label={resolvedMode === 'dark' ? 'Ganti ke mode terang' : 'Ganti ke mode gelap'}
            >
              {resolvedMode === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            {/* Profile Button */}
            <button
              className="profile-btn"
              disabled={!ready}
              onClick={() => {
                setDraft(state.name)
                setProfile(true)
                setMenu(false)
              }}
              aria-label="Buka profil belajar"
            >
              <span className="avatar">
                <UserRound size={17} strokeWidth={1.8} />
              </span>
              <span className="profile-name">{state.name || 'Pelajar'}</span>
              <ChevronDown size={13} className="profile-caret" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              className="mobile-menu icon-btn"
              aria-label={menu ? 'Tutup menu navigasi' : 'Buka menu navigasi'}
              aria-expanded={menu}
              aria-controls="mobile-nav"
              onClick={() => setMenu(!menu)}
            >
              {menu ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Reconstructed Mobile Drawer Menu */}
        {menu && (
          <div className="mobile-drawer-portal">
            <div
              className="mobile-drawer-backdrop"
              onClick={() => setMenu(false)}
              aria-hidden="true"
            />
            <aside
              id="mobile-nav"
              className="mobile-drawer"
              role="dialog"
              aria-modal="true"
              aria-label="Menu Navigasi Seluler"
            >
              {/* Drawer Top Header */}
              <div className="mobile-drawer-top">
                <div className="mobile-drawer-brand">
                  <Logo small />
                </div>
                <button
                  type="button"
                  className="mobile-drawer-close icon-btn"
                  onClick={() => setMenu(false)}
                  aria-label="Tutup menu"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Drawer Scrollable Content */}
              <div className="mobile-drawer-content">
                {/* User & Theme Quick Card */}
                <div className="mobile-drawer-user-card">
                  <div className="mobile-drawer-user-info">
                    <span className="avatar">
                      <UserRound size={17} />
                    </span>
                    <div>
                      <div className="mobile-drawer-user-label">Nama Pelajar</div>
                      <div className="mobile-drawer-user-name">{state.name || 'Pelajar RuangRumus'}</div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="mobile-drawer-edit-btn"
                    onClick={() => {
                      setDraft(state.name)
                      setProfile(true)
                      setMenu(false)
                    }}
                  >
                    Ubah
                  </button>
                </div>

                {/* Theme Mode Segmented Controller */}
                <div className="mobile-theme-segment-wrap">
                  <div className="mobile-section-heading">Tampilan & Tema</div>
                  <div className="mobile-theme-segment" role="radiogroup" aria-label="Mode Tampilan">
                    <button
                      type="button"
                      role="radio"
                      aria-checked={mode === 'light'}
                      className={'mobile-theme-pill ' + (mode === 'light' ? 'active' : '')}
                      onClick={() => setMode('light')}
                    >
                      <Sun size={14} />
                      <span>Terang</span>
                    </button>
                    <button
                      type="button"
                      role="radio"
                      aria-checked={mode === 'dark'}
                      className={'mobile-theme-pill ' + (mode === 'dark' ? 'active' : '')}
                      onClick={() => setMode('dark')}
                    >
                      <Moon size={14} />
                      <span>Gelap</span>
                    </button>
                    <button
                      type="button"
                      role="radio"
                      aria-checked={mode === 'system'}
                      className={'mobile-theme-pill ' + (mode === 'system' ? 'active' : '')}
                      onClick={() => setMode('system')}
                    >
                      <span>Sistem</span>
                    </button>
                  </div>
                </div>

                {/* Section 1: Navigation Links for Active Subject */}
                <div className="mobile-drawer-section">
                  <div className="mobile-section-heading">
                    <span>Menu {currentSubject.name}</span>
                    <span className="mobile-badge-pill">{currentSubject.badge}</span>
                  </div>
                  <nav className="mobile-nav-list" aria-label="Navigasi mapel aktif">
                    {navRoutes.map(([url, label, IconComponent]) => {
                      const active = isNavActive(url)
                      return (
                        <Link
                          key={url}
                          href={url}
                          className={'mobile-nav-link ' + (active ? 'active' : '')}
                          onClick={() => setMenu(false)}
                        >
                          <span className="mobile-nav-link-icon">
                            <IconComponent size={17} />
                          </span>
                          <span className="mobile-nav-link-text">{label}</span>
                          {active ? (
                            <span className="mobile-nav-link-active-tag">
                              <Check size={14} />
                            </span>
                          ) : (
                            <ChevronRight size={14} className="mobile-nav-link-arrow" />
                          )}
                        </Link>
                      )
                    })}
                  </nav>
                </div>

                {/* Section 2: Switch Subject */}
                <div className="mobile-drawer-section">
                  <div className="mobile-section-heading">
                    <span>Ganti Mata Pelajaran</span>
                  </div>
                  <div className="mobile-subject-cards">
                    {allSubjects.map((sub) => {
                      const isCurrent = sub.slug === slug
                      return (
                        <Link
                          key={sub.id}
                          href={subjectRoute(sub.slug)}
                          className={'mobile-subject-btn ' + (isCurrent ? 'selected' : '')}
                          onClick={() => setMenu(false)}
                        >
                          <div className="mobile-subject-btn-left">
                            <span className={'subject-color-dot dot-' + sub.theme} />
                            <span className="mobile-subject-btn-title">{sub.name}</span>
                          </div>
                          {isCurrent ? (
                            <span className="mobile-subject-btn-tag active">Aktif</span>
                          ) : (
                            <ChevronRight size={14} className="mobile-nav-link-arrow" />
                          )}
                        </Link>
                      )
                    })}
                  </div>
                </div>
              </div>

              {/* Drawer Footer */}
              <div className="mobile-drawer-footer">
                <span>RuangRumus SMA • Bimbingan & Try Out</span>
              </div>
            </aside>
          </div>
        )}
      </header>

      {profile && (
        <Dialog title="Profil belajar" onClose={() => setProfile(false)}>
          <p className="muted">Nama ini hanya tersimpan di perangkatmu.</p>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              if (name.trim()) {
                setName(name)
                setProfile(false)
              }
            }}
          >
            <label className="field-label" htmlFor="profile-name">
              Nama panggilan
            </label>
            <input
              id="profile-name"
              className="text-input"
              autoFocus
              required
              maxLength={28}
              value={name}
              onChange={(e) => setDraft(e.target.value)}
              autoComplete="nickname"
            />
            <div className="dialog-actions">
              <button type="button" className="btn btn-outline" onClick={() => setProfile(false)}>
                Batal
              </button>
              <button className="btn btn-primary" disabled={!name.trim()}>
                Simpan nama
              </button>
            </div>
          </form>
        </Dialog>
      )}
    </>
  )
}

export function Footer() {
  const { currentSubject } = useRoute()
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <Logo small />
        <span>Ruang belajar Try Out SMA · {currentSubject.name}</span>
        <span className="footer-local">
          <HardDrive size={14} /> Progres tersimpan di perangkat ini
        </span>
      </div>
    </footer>
  )
}
